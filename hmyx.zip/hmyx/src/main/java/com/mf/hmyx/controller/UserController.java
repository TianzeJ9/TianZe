package com.mf.hmyx.controller;


import com.mf.hmyx.dto.Product;
import com.mf.hmyx.dto.User;
import com.mf.hmyx.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 *  前端控制器
 */
@RestController
@RequestMapping("/hmyx/user")
public class UserController {
    @Autowired
    private UserMapper usermapper;

    @GetMapping("/add")
    public int add(@RequestParam(value="name",required=true,defaultValue = "name")String name,
                   @RequestParam(value="age",required=true,defaultValue = "age")String age,
                   @RequestParam(value="gender",required=true,defaultValue = "gender")String gender)
    {
        System.out.println("添加成功");
        return usermapper.insert(new User(name,age,gender));
    }


}
