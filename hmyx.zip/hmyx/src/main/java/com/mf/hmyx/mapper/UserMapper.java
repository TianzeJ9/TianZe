package com.mf.hmyx.mapper;

import com.mf.hmyx.dto.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author tianze
 * @since 2021-05-17
 */
@Repository
public interface UserMapper extends BaseMapper<User> {
    //查询接口
    int add(String name,String age,String gender);
}
