package com.mf.hmyx.service.impl;

import com.mf.hmyx.dto.User;
import com.mf.hmyx.mapper.UserMapper;
import com.mf.hmyx.service.UserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author tianze
 * @since 2021-05-17
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

}
