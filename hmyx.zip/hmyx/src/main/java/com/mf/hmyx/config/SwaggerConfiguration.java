package com.mf.hmyx.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.env.Profiles;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerConfiguration {
    //通过多个docket 每个组查阅不同的controller
    @Bean
    //Environment是springframework里的Environment
    public Docket createRestApia(Environment environment) {
        //获取环境 如果环境是下面写的两个其中一个 flag为true如果都不是则为false
        Profiles profiles = Profiles.of("dev","test");
        //传递环境
        boolean flag = environment.acceptsProfiles(profiles);
        return new Docket(DocumentationType.SWAGGER_2)
                .apiInfo(apiInfo())
                .enable(flag)
                .groupName("B");
    }

    @Bean
    public Docket createRestApimf(Environment environment) {
        //获取环境 如果环境是下面写的两个其中一个 flag为true如果都不是则为false
        Profiles profiles = Profiles.of("dev","test");
        //传递环境
        boolean flag = environment.acceptsProfiles(profiles);
        return new Docket(DocumentationType.SWAGGER_2)
                .apiInfo(apiInfo())
                //代表右上角的分组 多个Docket有多个组显示
                .groupName("mf")
                //  .enable(false)表示不启动
                .enable(flag)
                .select()
                //是swagger scan base package,这是扫描注解的配置，即你的API接口位置。
                // 用这个才能把有api接口的东西显示在网上
                //指定扫描的包
                .apis(RequestHandlerSelectors.basePackage("com.mf.hmyx.controller"))
                //any()扫描全部
                .paths(PathSelectors.any())
                .build();
    }

    /**
     * 创建该API的基本信息（这些基本信息会展现在文档页面中）
     * 访问地址：http://项目实际地址/swagger-ui.html
     * @return
     */
    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title("Spring Boot中使用Swagger2构建RESTful APIs")
                .description("更多请关注http://www.baidu.com")
                .termsOfServiceUrl("http://www.baidu.com")
                .version("1.0")
                .build();
    }


}