package com.mf.hmyx.controller;


import com.mf.hmyx.dto.Product;
import com.mf.hmyx.mapper.ProductMapper;
import com.mf.hmyx.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 商品信息 前端控制器
 * </p>
 *
 * @author tianze
 * @since 2021-05-10
 */
@RestController
@RequestMapping("/hmyx/product")
public class ProductController {

    @Autowired
    private ProductMapper productmapper;
    @Autowired
    private ProductService productservice;
    @RequestMapping("/index")
    public String test1(){
        return "index";
    }
    @RequestMapping("/A")
    public List<Product> test() {
        List<Product> userList = productmapper.selectList(null);
        userList.forEach(System.out::println);

        return userList;
    }

    /**
     * 查询全部
     * @return
     */
    @GetMapping("/list")
    public Object list(){
        System.out.println("查询成功");
        return productmapper.selectAll(null);
    }

    /**
     * 根据id删除
     * @param brandId
     * @return
     */
    @GetMapping("/delete")
    public boolean delete(Long brandId){
        System.out.println("删除成功");
        return productservice.removeById(brandId);
    }

    /**
     *  根据id查询
     * @param brandId
     * @return
     */
    @GetMapping("/byid2")
    public Product selectById(long brandId){
        System.out.println("查询成功");
        return productservice.ById(brandId);
    }

    /**
     *  修改
     * @param product
     * @return
     */
    @PostMapping("/update")
    public boolean update(@RequestBody Product product){
        System.out.println("修改成功");
        return productservice.updateById(product);
    }

    @GetMapping("/byid")
    public Object byid(long id){
        System.out.println("查询成功");
        return productservice.getById(id);
    }

    /**
     * 添加
     * @param product
     * @return
     */
    @PostMapping("/add")
    public boolean add(@RequestBody Product product){
        System.out.println("添加成功");
        return productservice.save(product);
    }
}
