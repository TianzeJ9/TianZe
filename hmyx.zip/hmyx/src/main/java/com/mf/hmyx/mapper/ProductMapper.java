package com.mf.hmyx.mapper;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.mf.hmyx.dto.Product;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.io.Serializable;
import java.util.List;

/**
 * <p>
 * 商品信息 Mapper 接口
 * </p>
 *
 * @author tianze
 * @since 2021-05-10
 */
@Repository
public interface ProductMapper extends BaseMapper<Product> {

    @Select("select * from hmyx_product where brand_id = #{id}")
    Product selectById(long id);
    //查出product表的brand_id
    @Select("select name from hmyx_product")
    List<Product> selectAll(@Param("name") Wrapper<Product> wrapper);

}
