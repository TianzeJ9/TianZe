package com.mf.hmyx.service;

import com.mf.hmyx.dto.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author tianze
 * @since 2021-05-17
 */
public interface UserService extends IService<User> {

}
