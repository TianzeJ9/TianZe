package com.mf.hmyx.service.impl;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.mf.hmyx.dto.Product;
import com.mf.hmyx.mapper.ProductMapper;
import com.mf.hmyx.service.ProductService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 商品信息 服务实现类
 * </p>
 *
 * @author tianze
 * @since 2021-05-10
 */
@Service
public class ProductServiceImpl extends ServiceImpl<ProductMapper, Product> implements ProductService {
    @Autowired
    private ProductMapper productmapper;

    @Override
    public Product ById(long id) {
        return productmapper.selectById(id);
    }

}
