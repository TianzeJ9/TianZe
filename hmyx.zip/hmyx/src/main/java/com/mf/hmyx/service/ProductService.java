package com.mf.hmyx.service;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.mf.hmyx.dto.Product;
import com.baomidou.mybatisplus.extension.service.IService;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 商品信息 服务类
 * </p>
 *
 * @author tianze
 * @since 2021-05-10
 */

public interface ProductService extends IService<Product> {
    Product ById(long id);

}
